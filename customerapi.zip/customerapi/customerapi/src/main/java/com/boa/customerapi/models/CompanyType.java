package com.boa.customerapi.models;

public enum CompanyType {
PUBLIC,PRIVATE,NGO
}
