package com.boa.customerapi.models;

public enum Gender {
MALE,FEMALE,TRANSGENDER
}
